
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include "app_uart.h"
#include "app_error.h"
#include "nrf_drv_twi.h"
#include "nrf_delay.h"
#include "nrf.h"
#include "bsp.h"
#include "Common.h"
#include "nrf_temp.h"

#if 0
	#define	Sensor_SCL				17/*21*/
	#define	Sensor_SDA				16/*22*/
#endif

#define MAX_TEST_DATA_BYTES     (15U)                /**< max number of test bytes to be used for tx and rx. */
#define UART_TX_BUF_SIZE 256                         /**< UART TX buffer size. */
#define UART_RX_BUF_SIZE 256                         /**< UART RX buffer size. */

/* TWI instance ID. */
#define TWI_INSTANCE_ID     0

extern	void InitTimerIRQ(void);

void uart_error_handle(app_uart_evt_t * p_event)
{
    if (p_event->evt_type == APP_UART_COMMUNICATION_ERROR)
    {
        APP_ERROR_HANDLER(p_event->data.error_communication);
    }
    else if (p_event->evt_type == APP_UART_FIFO_ERROR)
    {
        APP_ERROR_HANDLER(p_event->data.error_code);
    }
}

void uart_init(void)
{
	uint32_t		err_code;
	const app_uart_comm_params_t comm_params =
		{
			19,
			18,
			RTS_PIN_NUMBER,
			CTS_PIN_NUMBER,
			APP_UART_FLOW_CONTROL_DISABLED,
			false,
			UART_BAUDRATE_BAUDRATE_Baud115200
	};
	APP_UART_FIFO_INIT(&comm_params,
						UART_RX_BUF_SIZE,
						UART_TX_BUF_SIZE,
						uart_error_handle,
						APP_IRQ_PRIORITY_LOWEST,
						err_code);
	APP_ERROR_CHECK(err_code);
}

/**

	* @brief Function for main application entry.
*/
extern	void DS18B20_Run(void);
int main(void)
{
	uint32_t		ReturnValue = 0x99;
    int32_t			volatile temp;
	//	long			GetTempCnt = 0;

	uart_init();
    nrf_temp_init();

	nrf_gpio_cfg_output(MotorControl_A);
	nrf_gpio_cfg_output(MotorControl_B);
	nrf_gpio_cfg_output(MotorControl_C);
	nrf_gpio_cfg_output(MotorControl_D);
	//	nrf_gpio_cfg_output(
	//	nrf_gpio_cfg_input(DS18B20_Data	, 

    printf("\r\nProgram Start: \r\n");
	//	nrf_delay_ms(4000);
	//abc	InitTimerIRQ();
	nrf_gpio_cfg_output(LED);
	nrf_gpio_pin_set(LED);
	//	nrf_delay_us(20);
	//	nrf_gpio_pin_toggle(DS18B20_Trace);
/*
	DS18B20_Init();
	printf("Reset OK\r\n");
*/
	//	DS18B20_GetTemp();
	//abc	ReturnValue = DS18B20_Init();
	//abc	printf(" (A0001) %X\r\n", ReturnValue);

	//	gDutycycleId = 10;
	while(1)
	{
	#if 1
		DS18B20_Run();
		printf(" (A0002) %X\r\n", ReturnValue);
		//	DS18B20_Reset();
		//	DS18B20_GetTemp();
	#else
        NRF_TEMP->TASKS_START = 1; /** Start the temperature measurement. */

        /* Busy wait while temperature measurement is not finished, you can skip waiting if you enable interrupt for DATARDY event and read the result in the interrupt. */
        /*lint -e{845} // A zero has been given as right argument to operator '|'" */
        while (NRF_TEMP->EVENTS_DATARDY == 0)
        {
            // Do nothing.
        }
        NRF_TEMP->EVENTS_DATARDY = 0;

        /**@note Workaround for PAN_028 rev2.0A anomaly 29 - TEMP: Stop task clears the TEMP register. */
        temp = (nrf_temp_read() / 4);

        /**@note Workaround for PAN_028 rev2.0A anomaly 30 - TEMP: Temp module analog front end does not power down when DATARDY event occurs. */
        NRF_TEMP->TASKS_STOP = 1; /** Stop the temperature measurement. */

        //	NRF_LOG_INFO("Actual temperature: %d\r\n", (int)temp);
		printf(" >> Get Temperature(%d): %d	", GetTempCnt++, (int)temp);
	#endif
		nrf_delay_ms(1000);
        //	DS18B20_GetTemp();
	}
}


/** @} */
