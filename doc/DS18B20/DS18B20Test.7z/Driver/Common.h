#ifndef	_Common_h_
#define	_Common_h_

#define	MotorControl_A							12
#define	MotorControl_B							14
#define	MotorControl_C							29
#define	MotorControl_D							27

#define	LED										22

#define	ReverseKey								25

#define	UARTDebug_TX							18				// For Debug: TX
#define	UARTDebug_RX							19				// For Debug: RX

//	#define	TIMER1_PEROID							0x8000			// �Ʀr�U�p, �P���U�u (�{���U��). �T�w��
#define	TIMER1_PEROID							2

#define	MaxTickValue							10

#define Skip_ROM 		0xCC
#define Convert_T 		0x44
#define Read_scratchpad 0xBE

extern	void uart_config(uint8_t txd_pin_number, uint8_t rxd_pin_number);
extern	void uart_putstring(char* str);
extern	void InitTimerIRQ(void);
extern	void PWMOutput(void);
extern	unsigned char DS18B30_reset(void);
extern	void DS18B30_write(char WRT);
extern	unsigned char DS18B30_read(void);

extern	unsigned long	Timer1_GlobalTick;
extern	char	Direct[4];
extern	unsigned char	Timer1_Tick;
extern	uint_fast16_t timer0_cc0_period;
extern	uint_fast16_t timer1_cc0_period;
extern	unsigned char	gDutycycleId;

#endif	// _Common_h_
